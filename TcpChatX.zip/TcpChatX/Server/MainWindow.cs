﻿using System;
using Xwt;
using Xwt.Formats;

namespace Server
{
	public class MainWindow : Window
	{
		public MainWindow()
		{
			Title = "Xwt Demo Application";
			//Width = 500;
			//Height = 400;

			VBox topPanel;
			HBox firstRow, thirdRow;
			RichTextView textView;

			this.Content = topPanel = new VBox();

			topPanel.PackStart(firstRow = new HBox());
			topPanel.PackStart(textView = new RichTextView() { ExpandVertical = true, MinHeight = 200, ExpandHorizontal = true,  }, true, true);
			textView.LoadText("testiufusbydbfiguysidfbglfknsdk\nyfbgsdilfuygushidfukgbsdofsgbdfougsbdfgu\nysodbfuygsifusodfubsgdofbygusdfugyjsbdfkgjsdbf", TextFormat.Plain );
			topPanel.PackStart(thirdRow = new HBox());
			firstRow.PackStart(new TextEntry());
			firstRow.PackStart(new TextEntry());
			firstRow.PackStart(new Button());

			thirdRow.ExpandHorizontal = true;
			thirdRow.PackStart(new TextEntry()
			{
				PlaceholderText = "Message..."
			}, true, true);
			thirdRow.PackStart(new Button() { Label = "Send" } );
		}
	}
}
