﻿using System;
namespace Server
{
	using System;
	using Xwt;

	class Program
	{
		[STAThread]
		static void Main()
		{
			Application.Initialize();
			var mainWindow = new MainWindow();
			mainWindow.Show();
			Application.Run();
			mainWindow.Dispose();
		}
	}

}
